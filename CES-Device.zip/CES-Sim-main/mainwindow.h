#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QListWidget>
#include <QTimer>
#include <string>
#include "cesdevice.h"
#include "therapy.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

    public:
        MainWindow(QWidget *parent = nullptr);
        ~MainWindow();
        QListWidget *currentMenu;

    private:
        Ui::MainWindow *ui;
        CESDevice      *device;
        bool           contact;
        Therapy        *currentTherapy;

        QStringList mainMenu;
        QStringList optionMenu;
        QStringList waveformMenu;
        QStringList frequencyMenu;
        QStringList durationMenu;
        QStringList saveMenu;
        QStringList therapyMenu;

        QTimer*     internalClock;
        char        timeString[8];
        char        therapyString[512];
        const char letters[3][3] = {"α", "β", "γ"};
        void setMenu(QStringList);
        void powerChange(bool);
        void tick();

    private slots:
        void menuUp();
        void menuDown();
        void menuOk();
        void menuBack();
        void menuSkin();
        void menuPower();
        void menuSpeed();
        void menuZap();
        void batteryChange(int);
};
#endif // MAINWINDOW_H

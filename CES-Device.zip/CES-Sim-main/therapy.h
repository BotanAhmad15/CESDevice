#ifndef THERAPY_H
#define THERAPY_H

#include <QObject>
#include <time.h>

enum class Waveform {
    ALPHA,
    BETA,
    GAMMA
};

enum class Frequency {
    LOW = 5,
    MED = 770,
    HI  = 1000
};

enum class Duration {
    LOW = 20,
    MED = 40,
    HI  = 60
};

class Therapy : public QObject
{
    Q_OBJECT
public:
    explicit Therapy(QObject *parent = nullptr);

    time_t startTime;
    Waveform waveform;
    Frequency frequency;
    Duration duration;
    int powerLevel;

signals:

};

#endif // THERAPY_H

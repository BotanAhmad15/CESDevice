#ifndef CESDEVICE_H
#define CESDEVICE_H

#include <QObject>
#include <QTimer>
#include "therapy.h"

class CESDevice : public QObject
{
    Q_OBJECT
public:
    explicit CESDevice(QObject *parent = nullptr);
    ~CESDevice();

    bool getIsPowerOn();
    bool getIsCircuitClosed();
    bool getTherapyStatus();
    bool getIsDisabled();
    QList<Therapy*> getPastTherapies();
    void pushTherapy();
    double getBattery();
    void setBattery(double);
    int getRemainingTime();
    void setRemainingTime(int);
    QTimer* getTimer();
    void disable();

signals:
    void isPowerOnChanged(bool);
    void isCircuitClosedChanged(bool);

public slots:
    void pressPowerButton();
    void pressSkinContactButton();
    void startTherapy(Therapy*);
    void stopTherapy();

private:
    bool isCircuitClosed;
    bool isTherapyStarted;
    bool isDisabled;
    bool isPowerOn;
    float batteryLevel;
    int  therapyClock;
    QTimer* therapyTimer;
    QTimer* autoOffTimer;
    Therapy *currentTherapy;
    QList<Therapy*> pastTherapies;
};

#endif // CESDEVICE_H

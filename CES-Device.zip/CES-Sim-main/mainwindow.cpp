#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QDebug>
#include <time.h>

template<typename E>
constexpr auto to_integral(E e) -> typename std::underlying_type<E>::type
{
    return static_cast<typename std::underlying_type<E>::type>(e);
}

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    device = new CESDevice(this);

    mainMenu      << "Start new therapy" << "View previous therapies";
    optionMenu    << "Select waveform" << "Select frequency" << "Select duration" << "Begin therapy";
    waveformMenu  << "ALPHA" << "BETA" << "GAMMA";
    frequencyMenu << "0.5" << "77.0" << "100.0";
    durationMenu  << "20 minutes" << "40 minutes" << "60 minutes";
    saveMenu      << "Save current therapy" << "Discard current therapy";
    therapyMenu   << "Past therapies";

    currentMenu = ui->listDisplay;
    setMenu(mainMenu);

    ui->warning->setVisible(false);
    ui->timeDisplay->setVisible(false);

    internalClock = new QTimer(this);
    connect(internalClock, &QTimer::timeout, this, &MainWindow::tick);
    internalClock->start(1000);

    connect(ui->up,    &QPushButton::pressed, this, &MainWindow::menuUp);
    connect(ui->down,  &QPushButton::pressed, this, &MainWindow::menuDown);
    connect(ui->ok,    &QPushButton::pressed, this, &MainWindow::menuOk);
    connect(ui->back,  &QPushButton::pressed, this, &MainWindow::menuBack);
    connect(ui->skin,  &QPushButton::pressed, this, &MainWindow::menuSkin);
    connect(ui->power, &QPushButton::pressed, this, &MainWindow::menuPower);
    connect(ui->zap,   &QPushButton::pressed, this, &MainWindow::menuZap);
    connect(ui->speedTherapy, &QPushButton::pressed, this, &MainWindow::menuSpeed);
    connect(ui->batterySpinBox, SIGNAL(valueChanged(int)), this, SLOT(batteryChange(int)));
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::menuSkin() {
    if (device->getIsCircuitClosed()){
        QEventLoop delay;
        QTimer timer;
        timer.connect(&timer, &QTimer::timeout, &delay, &QEventLoop::quit);
        timer.start(3000);
        ui->warning->setVisible(true);
        ui->warning->setPlainText("           [WARNING:]\n       Skin contact loss.\n");
        delay.exec();
        ui->warning->setVisible(false);
        timer.start(2000);
        delay.exec();
        device->pressSkinContactButton();
    }
    else {device->pressSkinContactButton();}
}

void MainWindow::menuZap() {
    device->disable();
    device->stopTherapy();
    powerChange(false);
}

void MainWindow::menuSpeed() {
    device->setRemainingTime(13);
}

void MainWindow::menuPower() {
    if (device->getIsDisabled()) return;
    powerChange(!device->getIsPowerOn());
}

void MainWindow::tick() {
    int t = device->getRemainingTime();
    if (device->getTherapyStatus() && device->getIsCircuitClosed()) {
        if (t % 10 == 0) ui->batterySpinBox->setValue(device->getBattery() - 1);
        device->setRemainingTime(--t);
        snprintf(timeString, 8, "%02d:%02d", t/60, t%60);
        ui->timeDisplay->setPlainText(timeString);

        if(t < 1) {
            device->stopTherapy();
            ui->timeDisplay->setVisible(false);
            setMenu(saveMenu);
            ui->listDisplay->setVisible(true);
            ui->infoBar->setPlainText("");
            ui->ampBar->setPlainText("");
        }
    }
}

void MainWindow::setMenu(QStringList menu) {
    currentMenu->clear();
    currentMenu->addItems(menu);
    currentMenu->setCurrentRow(0);
}

void MainWindow::menuUp() {
    if (device->getTherapyStatus()) {
        if      (currentTherapy->powerLevel < 500) currentTherapy->powerLevel += 50;
        snprintf(therapyString, 512, "%d μA", currentTherapy->powerLevel);
        ui->ampBar->setPlainText(therapyString);
    }
    else {
        int next = currentMenu->currentRow() - 1;
        if (next < 0) {next = currentMenu->count() - 1;}
        currentMenu->setCurrentRow(next);
    }
}

void MainWindow::menuDown() {
    if (device->getTherapyStatus()) {
        if      (currentTherapy->powerLevel > 50) currentTherapy->powerLevel -= 100;
        else if (currentTherapy->powerLevel > 0)  currentTherapy->powerLevel -= 50;
        snprintf(therapyString, 512, "%d μA", currentTherapy->powerLevel);
        ui->ampBar->setPlainText(therapyString);
    }
    else {
        int next = currentMenu->currentRow() + 1;
        if (next == currentMenu->count()) {next = 0;}
        currentMenu->setCurrentRow(next);
    }
}

void MainWindow::menuOk() {
    QString index = currentMenu->currentItem()->text();
    if      (index.compare("Start new therapy") == 0) {
        currentTherapy = new Therapy;
        setMenu(optionMenu);
    }
    else if (index.compare("Select waveform") == 0)   {setMenu(waveformMenu);}
    else if (index.compare("Select frequency") == 0)  {setMenu(frequencyMenu);}
    else if (index.compare("Select duration") == 0)   {setMenu(durationMenu);}
    else if (index.compare("ALPHA") == 0) {
        currentTherapy->waveform = Waveform::ALPHA;
        setMenu(optionMenu);
    }
    else if (index.compare("BETA") == 0) {
        currentTherapy->waveform = Waveform::BETA;
        setMenu(optionMenu);
    }
    else if (index.compare("GAMMA") == 0) {
        currentTherapy->waveform = Waveform::GAMMA;
        setMenu(optionMenu);
    }
    else if (index.compare("0.5") == 0) {
        currentTherapy->frequency = Frequency::LOW;
        setMenu(optionMenu);
    }
    else if (index.compare("77.0") == 0) {
        currentTherapy->frequency = Frequency::MED;
        setMenu(optionMenu);
    }
    else if (index.compare("100.0") == 0) {
        currentTherapy->frequency = Frequency::HI;
        setMenu(optionMenu);
    }
    else if (index.compare("20 minutes") == 0) {
        currentTherapy->duration = Duration::LOW;
        setMenu(optionMenu);
    }
    else if (index.compare("40 minutes") == 0) {
        currentTherapy->duration = Duration::MED;
        setMenu(optionMenu);
    }
    else if (index.compare("60 minutes") == 0) {
        currentTherapy->duration = Duration::HI;
        setMenu(optionMenu);
    }
    else if (index.compare("Begin therapy") == 0) {
        device->startTherapy(currentTherapy);
        ui->listDisplay->setVisible(false);
        ui->timeDisplay->setVisible(true);
        snprintf(therapyString, 512, "%s | %.1f Hz",
                 letters[to_integral(currentTherapy->waveform)],
                 static_cast<float>(to_integral(currentTherapy->frequency)) / 10.0);
        ui->infoBar->setPlainText(therapyString);
        snprintf(therapyString, 512, "%d μA", currentTherapy->powerLevel);
        ui->ampBar->setPlainText(therapyString);

        int t = device->getRemainingTime();
        snprintf(timeString, 8, "%02d:%02d", t/60, t%60);
        ui->timeDisplay->setPlainText(timeString);
    }
    else if (index.compare("Save current therapy") == 0) {
        device->pushTherapy();
        setMenu(mainMenu);
    }
    else if (index.compare("Discard current therapy") == 0) {
        delete currentTherapy;
        setMenu(mainMenu);
    }
    else if (index.compare("View previous therapies") == 0) {
        setMenu(therapyMenu);
        QList<Therapy*> pastTherapies = device->getPastTherapies();
        for (int i = 0; i < pastTherapies.size(); i++) {
            snprintf(therapyString, 512, "Waveform: %s\nFrequency: %.1f Hz\nDuration: %d minutes\nStart Time: %ld\nLast Power Level: %d μA",
                     letters[to_integral(pastTherapies[i]->waveform)],
                     static_cast<float>(to_integral(pastTherapies[i]->frequency)) / 10.0,
                     to_integral(pastTherapies[i]->duration),
                     pastTherapies[i]->startTime,
                     pastTherapies[i]->powerLevel);
            currentMenu->addItem(therapyString);
        }
    }
}

void MainWindow::menuBack() {
    QString topItem = currentMenu->item(0)->text();
    if      (topItem.compare("Start new therapy") == 0) {return;}
    else if (topItem.compare("Select waveform") == 0)   {
        delete currentTherapy;
        setMenu(mainMenu);
    }
    else if (topItem.compare("Save current therapy") == 0)   {
        delete currentTherapy;
        setMenu(mainMenu);
    }
    else if (topItem.compare("ALPHA") == 0)             {setMenu(optionMenu);}
    else if (topItem.compare("0.5") == 0)               {setMenu(optionMenu);}
    else if (topItem.compare("20 minutes") == 0)        {setMenu(optionMenu);}
    else if (topItem.compare("Past therapies") == 0)    {setMenu(mainMenu);}
}

void MainWindow::powerChange(bool power) {
    if (power != device->getIsPowerOn()) {
        device->pressPowerButton();
        if (!power) ui->cover->raise();
        if (power)  ui->cover->lower();
        ui->listDisplay->setVisible(power);
        ui->up->setEnabled(power);
        ui->down->setEnabled(power);
        ui->ok->setEnabled(power);
        ui->back->setEnabled(power);
        ui->skin->setEnabled(power);
    }
}

void MainWindow::batteryChange(int value) {
    ui->warning->setVisible(false);
    ui->BatteryProgressBar->setValue(value);
    powerChange(true);
    double doubleValue = double(value);
    device->setBattery(doubleValue);
    if (device->getBattery() == 5){
        QEventLoop delay;
        QTimer timer;
        timer.connect(&timer, &QTimer::timeout, &delay, &QEventLoop::quit);
        timer.start(3000);
        ui->warning->setVisible(true);
        ui->warning->setPlainText("           [WARNING:]\n  Battery at 5% charge.");
        delay.exec();
        ui->warning->setVisible(false);
    }
    else if (device->getBattery() == 2){
        QEventLoop delay;
        QTimer timer;
        timer.connect(&timer, &QTimer::timeout, &delay, &QEventLoop::quit);
        timer.start(3000);
        ui->warning->setVisible(true);
        ui->warning->setPlainText("           [WARNING:]\n  Battery at 2% charge.\n  Device will shutdown.");
        delay.exec();
        ui->warning->setVisible(false);
        timer.start(10000);
        delay.exec();
        powerChange(false);
    }
    else if (device->getBattery() < 2){
        powerChange(false);
    }
}

#include "therapy.h"

Therapy::Therapy(QObject *parent) : QObject(parent) {
    waveform   = Waveform::ALPHA;
    frequency  = Frequency::LOW;
    duration   = Duration::LOW;
    powerLevel = 100;
}

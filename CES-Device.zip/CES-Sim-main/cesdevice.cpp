#include "cesdevice.h"
#include <QDebug>
#include <time.h>

//Credit Goes To https://www.py4u.net/discuss/65256
//Consider moving this to a separate file utils.h and utils.cpp
template<typename E>
constexpr auto to_integral(E e) -> typename std::underlying_type<E>::type
{
    return static_cast<typename std::underlying_type<E>::type>(e);
}

CESDevice::CESDevice(QObject *parent) : QObject(parent)
{
    //Instead of therapy timer being calibrated to therapy countdown cycle, maybe calibrate to a second interval and call a decrement countdown slot?
    therapyTimer     = new QTimer(this);
    connect(therapyTimer,SIGNAL(timeout()), this, SLOT(stopTherapy()));
    therapyClock     = 0;
    isDisabled       = false;
    batteryLevel     = 100.0f;
    isCircuitClosed  = false;
    isTherapyStarted = false;

    autoOffTimer = new QTimer(this);
    autoOffTimer->setInterval(30*60*1000);
    connect(autoOffTimer,SIGNAL(timeout()), this, SLOT(pressPowerButton()));
}

CESDevice::~CESDevice(){
    for (int i = 0 ; i < pastTherapies.length(); i++){
        delete pastTherapies[i];
    }

    if(isTherapyStarted) {
        delete currentTherapy;
    }

    delete therapyTimer;
    delete autoOffTimer;
}

//Getters

bool CESDevice::getIsPowerOn() {
    return isPowerOn;
}

bool CESDevice::getIsDisabled() {
    return isDisabled;
}


bool CESDevice::getIsCircuitClosed() {
    return  isCircuitClosed;
}

QList<Therapy*> CESDevice::getPastTherapies() {
    return pastTherapies;
}

void CESDevice::pushTherapy() {
    pastTherapies.push_back(currentTherapy);
}

void CESDevice::pressPowerButton() {
    if (isDisabled || batteryLevel <= 0.0f) return;

    isPowerOn = !isPowerOn;

    if (isPowerOn) {
        autoOffTimer->start();
    }
    else {
        autoOffTimer->stop();

        if(isTherapyStarted){
            delete currentTherapy;
            currentTherapy = nullptr;

            therapyTimer->stop();

            isTherapyStarted = false;
        }
    }

    emit isPowerOnChanged(isPowerOn);
}

void CESDevice::pressSkinContactButton() {
    isCircuitClosed = !isCircuitClosed;

    /*if(isPowerOn && isTherapyStarted) {
        int r = therapyTimer->remainingTime();
        therapyTimer->stop();
        therapyTimer->setInterval(r);
    }

    emit isCircuitClosedChanged(isCircuitClosed);*/
}



void CESDevice::startTherapy(Therapy *t){
    if(isTherapyStarted || !isPowerOn) return;

    currentTherapy = t;
    t->startTime = time(nullptr);

    //Set Start Time on Therapy

    //Start Therapy Timer
    therapyTimer->start(to_integral(t->duration)*60*1000);
    isTherapyStarted = true;
    therapyClock = to_integral(t->duration)*60;

    //Disable and reset Auto Off Timer
}


void CESDevice::setBattery(double level){
    batteryLevel = level;
}

double CESDevice::getBattery(){
    return batteryLevel;
}

void CESDevice::disable() {
    isDisabled = true;
}

void CESDevice::stopTherapy(){
    isTherapyStarted = false;
    isCircuitClosed  = false;
}

bool CESDevice::getTherapyStatus() {
    return isTherapyStarted;
}

int CESDevice::getRemainingTime() {
    return therapyClock;
}

void CESDevice::setRemainingTime(int t) {
    therapyClock = t;
}

QTimer* CESDevice::getTimer() {
    return therapyTimer;
}



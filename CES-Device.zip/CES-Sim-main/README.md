# 3004-Group-Project

1. Team number and member names.
Team 26.
- Botan Ahmad: 101076443
- Eren Kaya: 101122532
- Iain Found: 101109499
- Ghufran Wadud: 101120668

2. Who did what in the project.
- Botan Ahmad: Small contribution to use cases, UML class diagram, UI, coding. 
- Eren Kaya: Organized Meetings, Did most of Use Cases, All Tests, All Traceability Matrix, Some Coding (mostly in CESDevice.ccp)
- Iain Found: Small contribution to use cases, Activity Diagrams, Large amount of the coding (mainly menus and therapy functionality)
- Ghufran Wadud: Small contribution to use cases, Sequence Diagrams

3. File organization of the deliverables.
- Use cases, OO Design model, tests, and traceability matrix located in the doc folder.

4. Tested scenarios: ones that work and ones that don’t.
Powering on device - Working (Occasional bug on start up, if occurs restart)
Powering off device - Working
Circuit check when electrodes are in contact with skin - Working
Loss of skin concact during treatment for less than five seconds treatment may resume, otherwise stops - Working
Frequency options - Working
Countdown cycles - Working
Large display timer - Working
Treatment starts when electrodes touch skin - Working
500 μA (microampere) current control (1-10) incrementing, and decrementing - Working
30 minute auto off - Not implemented
Battery charge inddicator - Working
5% battery warning - Working
2% battery warning then shutdown - Working
Recording scenarios (add, view) - Working
Disable after fault develops - working

5. Other Notes
- Ghufran Wadud was away for 3 weeks and produced very little work. Can the requirements be relaxed a bit because of this?